const LOGO_URL = "https://blob.8004scan.app/ae6661ea5f6c31c764a08602269398691465ffd3d5b95441c2da36d74eba458d.jpg";

export default function SiteNav() {
  return (
    <nav className="fixed top-0 w-full z-50 bg-background/90 backdrop-blur-xl border-b border-foreground/10">
      <div className="container flex items-center justify-between h-16">
        <div className="flex items-center gap-3">
          <img src={LOGO_URL} alt="BasedOracle" className="w-8 h-8 rounded-lg" />
          <span className="font-display font-extrabold text-lg text-foreground">BasedOracle</span>
        </div>
        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors font-bold">Features</a>
          <a href="#token" className="text-sm text-muted-foreground hover:text-foreground transition-colors font-bold">$BASEORACLE</a>
          <a href="#api" className="text-sm text-muted-foreground hover:text-foreground transition-colors font-bold">API Docs</a>
          <a href="#chat" className="text-sm text-muted-foreground hover:text-foreground transition-colors font-bold">Chat</a>
        </div>
        <a
          href="#chat"
          className="px-5 py-2 rounded-lg bg-foreground text-background font-display font-extrabold text-sm hover:opacity-90 transition-all hover:scale-105"
        >
          Launch App
        </a>
      </div>
    </nav>
  );
}
