import React from "react";
import { motion } from "framer-motion";
import { Send, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export default function ChatSection() {
  const [query, setQuery] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [messages, setMessages] = React.useState<{ role: string; content: string }[]>([
    { role: "assistant", content: "👋 I'm BasedOracle AI — your onchain intelligence oracle for Base.\n\nAsk me about any wallet, token, project, or trend.\n\nTry: \"What is $BASEORACLE?\" or \"Analyze trending tokens on Base\"" },
  ]);
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!query.trim() || loading) return;
    const userMsg = query.trim();
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setQuery("");
    setLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke("chat-agent", {
        body: { message: userMsg },
      });

      if (error) throw error;

      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: data.reply || "I couldn't process that." },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "⚠️ Connection error. Please try again." },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="chat" className="py-24 bg-background">
      <div className="container">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="font-display text-3xl md:text-5xl font-extrabold text-foreground mb-4">
            Chat with BasedOracle AI
          </h2>
          <p className="text-muted-foreground text-lg font-medium">
            Live AI agent — ask anything about the Base ecosystem.
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto rounded-2xl border border-foreground/15 bg-card shadow-card overflow-hidden">
          {/* Terminal header */}
          <div className="p-4 border-b border-foreground/10 flex items-center gap-3">
            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-destructive/60" />
              <div className="w-3 h-3 rounded-full bg-muted-foreground/40" />
              <div className="w-3 h-3 rounded-full bg-foreground/30" />
            </div>
            <span className="text-muted-foreground text-xs font-mono font-bold">basedoracle.ai / live agent</span>
            <span className="ml-auto flex items-center gap-1.5 text-xs font-bold text-green-400">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              Live
            </span>
          </div>

          {/* Messages */}
          <div className="h-96 overflow-y-auto p-5 space-y-4">
            {messages.map((msg, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] px-5 py-3.5 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap font-medium ${
                    msg.role === "user"
                      ? "bg-foreground text-background rounded-br-md font-bold"
                      : "bg-secondary text-foreground rounded-bl-md"
                  }`}
                >
                  {msg.content}
                </div>
              </motion.div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="px-5 py-3.5 rounded-2xl rounded-bl-md bg-secondary text-foreground">
                  <Loader2 className="w-4 h-4 animate-spin" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-foreground/10 flex gap-3">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Ask BasedOracle anything..."
              disabled={loading}
              className="flex-1 px-5 py-3 rounded-xl bg-secondary text-foreground text-sm font-bold placeholder:text-muted-foreground placeholder:font-medium focus:outline-none focus:ring-2 focus:ring-foreground/30 disabled:opacity-50"
            />
            <button
              onClick={handleSend}
              disabled={loading}
              className="px-5 py-3 rounded-xl bg-foreground text-background font-display font-extrabold text-sm hover:opacity-90 transition-all hover:scale-105 flex items-center gap-2 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              Send
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
