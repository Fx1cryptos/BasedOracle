import { motion } from "framer-motion";
import ParticleBackground from "./ParticleBackground";

const LOGO_URL = "https://blob.8004scan.app/ae6661ea5f6c31c764a08602269398691465ffd3d5b95441c2da36d74eba458d.jpg";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background">
      <ParticleBackground />

      {/* Glow effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-oracle-glow/10 rounded-full blur-[120px]" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-oracle-glow/8 rounded-full blur-[100px]" />

      <div className="container relative z-10 pt-24 pb-16">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          {/* Logo */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mx-auto mb-8"
          >
            <img
              src={LOGO_URL}
              alt="BasedOracle AI Logo"
              className="w-28 h-28 rounded-2xl mx-auto shadow-glow border-2 border-foreground/20"
            />
          </motion.div>

          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="inline-flex items-center gap-2 px-5 py-2 rounded-full border border-foreground/20 bg-foreground/5 text-foreground text-sm font-bold mb-8"
          >
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            Live on Base Mainnet
          </motion.div>

          <h1 className="font-display text-5xl sm:text-6xl md:text-8xl font-extrabold leading-none mb-6 tracking-tight">
            <span className="text-gradient-hero">BasedOracle</span>
            <br />
            <span className="text-foreground">AI Agent</span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-12 leading-relaxed font-medium">
            Real-time onchain intelligence for the Base ecosystem. Wallet analysis, automated trading, airdrop management & social insights — powered by AI.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <a
              href="#chat"
              className="px-10 py-4 rounded-xl bg-foreground text-background font-display font-extrabold text-base shadow-hero hover:shadow-glow transition-all hover:scale-105"
            >
              Try the Agent
            </a>
            <a
              href="https://base-oracle--fx1digital.replit.app"
              target="_blank"
              rel="noreferrer"
              className="px-10 py-4 rounded-xl border-2 border-foreground text-foreground font-display font-extrabold text-base hover:bg-foreground/10 transition-all hover:scale-105"
            >
              Launch Live App
            </a>
          </div>

          {/* Live status indicators */}
          <div className="flex justify-center gap-6 flex-wrap">
            {[
              { label: "Wallets Analyzed", value: "184K+" },
              { label: "Trades Executed", value: "52K+" },
              { label: "Airdrops Tracked", value: "3.2K" },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 + i * 0.1 }}
                className="px-6 py-4 rounded-xl border border-foreground/15 bg-secondary"
              >
                <div className="font-display text-2xl font-extrabold text-foreground">{stat.value}</div>
                <div className="text-xs text-muted-foreground font-bold uppercase tracking-wider">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
