import { ExternalLink } from "lucide-react";

const LOGO_URL = "https://blob.8004scan.app/ae6661ea5f6c31c764a08602269398691465ffd3d5b95441c2da36d74eba458d.jpg";

const footerLinks = [
  { label: "GitHub", url: "https://github.com/Fx1cryptos/BasedOracle-AI" },
  { label: "X Community", url: "https://x.com/i/communities/1991809112070557893" },
  { label: "Base", url: "https://x.com/base" },
  { label: "Base App", url: "https://x.com/baseapp" },
  { label: "Zora", url: "https://zora.co/@basedoracle" },
  { label: "Clanker", url: "https://www.clanker.world/clanker/0x1402fB10817527C06Ec8AE145844A71c78c18B07" },
  { label: "Base Profile", url: "https://base.app/profile/basedoracle" },
];

export default function SiteFooter() {
  return (
    <footer className="py-12 border-t border-foreground/10">
      <div className="container">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 mb-8">
          <div className="flex items-center gap-3">
            <img src={LOGO_URL} alt="BasedOracle" className="w-10 h-10 rounded-lg" />
            <span className="font-display font-extrabold text-lg text-foreground">BasedOracle AI</span>
          </div>
          <div className="flex items-center gap-4 flex-wrap justify-center">
            {footerLinks.map((link) => (
              <a
                key={link.label}
                href={link.url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors font-bold"
              >
                {link.label}
                <ExternalLink className="w-3 h-3" />
              </a>
            ))}
          </div>
        </div>
        <div className="text-center text-sm text-muted-foreground font-bold">
          <p>© 2026 BasedOracle AI. All rights reserved.</p>
          <p className="mt-1">Powered by <a href="https://base.org" target="_blank" rel="noreferrer" className="text-foreground hover:underline">Base</a></p>
        </div>
      </div>
    </footer>
  );
}
