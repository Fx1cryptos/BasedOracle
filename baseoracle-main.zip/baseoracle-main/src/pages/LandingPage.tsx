import SiteNav from "@/components/SiteNav";
import HeroSection from "@/components/HeroSection";
import FeaturesSection from "@/components/FeaturesSection";
import TokenSection from "@/components/TokenSection";
import ApiDocsSection from "@/components/ApiDocsSection";
import ChatSection from "@/components/ChatSection";
import SocialProofSection from "@/components/SocialProofSection";
import SiteFooter from "@/components/SiteFooter";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background font-body">
      <SiteNav />
      <HeroSection />
      <FeaturesSection />
      <TokenSection />
      <ChatSection />
      <SocialProofSection />
      <ApiDocsSection />
      <SiteFooter />
    </div>
  );
}
